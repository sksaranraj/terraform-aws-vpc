2 ec2 with 1 ALB created
all the end to end are included in the terraform
For easier reference i had used all the VAriables in the same Main file itself as hardcoded value.